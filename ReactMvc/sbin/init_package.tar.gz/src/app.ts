import * as $ from "jquery";
export class App {
    public addComment():void {
        let creatAt = new Date();
        $("#main").append("<div><span>new comment pushed at."+creatAt.toTimeString()+"</span>");
    }
}
let app = new App();
//jquery $()
$(()=>{
    $("#btn-add").click(app.addComment);
});